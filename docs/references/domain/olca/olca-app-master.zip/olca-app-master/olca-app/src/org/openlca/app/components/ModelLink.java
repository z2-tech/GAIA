package org.openlca.app.components;

import java.util.Objects;
import java.util.function.Consumer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ImageHyperlink;
import org.openlca.app.App;
import org.openlca.app.M;
import org.openlca.app.db.Database;
import org.openlca.app.rcp.images.Icon;
import org.openlca.app.rcp.images.Images;
import org.openlca.app.util.Controls;
import org.openlca.app.util.Labels;
import org.openlca.app.util.UI;
import org.openlca.commons.Strings;
import org.openlca.core.database.IDatabase;
import org.openlca.core.model.ModelType;
import org.openlca.core.model.RootEntity;
import org.openlca.core.model.descriptors.Descriptor;

public class ModelLink<T extends RootEntity> {

	private final IDatabase db;
	private final Class<T> type;
	private final ModelType modelType;

	private ImageHyperlink link;
	private Consumer<T> onChange;
	private T model;
	private boolean editable = true;

	private ModelLink(Class<T> type) {
		this.db = Objects.requireNonNull(Database.get());
		this.type = Objects.requireNonNull(type);
		this.modelType = ModelType.of(type);
	}

	public static <T extends RootEntity> ModelLink<T> of(Class<T> type) {
		return new ModelLink<>(type);
	}

	/// Set if the model link is enabled or not. This has to be set before the
	/// model links is rendered because it looks different then.
	public ModelLink<T> setEditable(boolean editable) {
		this.editable = editable;
		return this;
	}

	public ModelLink<T> onChange(Consumer<T> fn) {
		this.onChange = fn;
		return this;
	}

	public ModelLink<T> renderOn(Composite parent, FormToolkit tk, String label) {
		UI.label(parent, tk, label);
		return renderOn(parent, tk);
	}

	public ModelLink<T> renderOn(Composite parent, FormToolkit tk) {
		var comp = UI.composite(parent, tk, SWT.FILL);
		UI.gridLayout(comp, editable ? 3 : 1, 10, 0);

		// the selection handler of this widget
		Runnable doSelect = () -> select(ModelSelector.select(modelType));

		// selection button
		if (editable) {
			var btn = UI.imageHyperlink(comp, tk, SWT.BORDER);
			btn.setToolTipText(M.SelectADataset);
			btn.setImage(Images.get(modelType));
			Controls.onClick(btn, _ -> doSelect.run());
		}

		// the link
		link = UI.imageHyperlink(comp, tk, SWT.NONE);
		if (!editable) {
			link.setImage(Images.get(modelType));
		}
		Controls.onClick(link, _ -> {
			if (model != null) {
				App.open(model);
			} else if (editable) {
				doSelect.run();
			}
		});
		if (editable) {
			ModelTransfer.onDrop(link, ds -> {
				if (!ds.isEmpty()) {
					select(ds.get(0));
				}
			});
		}

		// the delete button
		if (editable) {
			var deleteBtn = UI.imageHyperlink(comp, tk, SWT.TOP);
			deleteBtn.setToolTipText(M.Remove);
			deleteBtn.setHoverImage(Icon.DELETE.get());
			deleteBtn.setImage(Icon.DELETE_DISABLED.get());
			Controls.onClick(deleteBtn, _ -> {
				model = null;
				updateLinkText();
				if (onChange != null) {
					onChange.accept(null);
				}
			});
		}

		updateLinkText();
		return this;
	}

	private void select(Descriptor d) {
		if (d == null
			|| d.type == null
			|| !Objects.equals(d.type.getModelClass(), type))
			return;
		model = db.get(type, d.id);
		updateLinkText();
		if (onChange != null) {
			onChange.accept(model);
		}
	}

	/**
	 * Set the model of this link to the given value without firing
	 * an {@code onChange} event.
	 */
	public ModelLink<T> setModel(T model) {
		this.model = model;
		updateLinkText();
		return this;
	}

	private void updateLinkText() {
		if (link == null)
			return;
		var text = model == null
			? M.NoneHyphen
			: Labels.name(model);
		link.setText(Strings.cutEnd(text, 120));
		link.setToolTipText(text);
		link.getParent().pack();
	}

}
