package org.openlca.app.editors.graphical.edit;

import static org.openlca.app.components.graphics.model.Component.*;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;
import org.openlca.app.components.graphics.model.Component;

public abstract class ComponentEditPart<N extends Component> extends
	AbstractGraphicalEditPart implements PropertyChangeListener {

	/**
	 * Upon activation, attach to the model element as a property change
	 * listener.
	 */
	@Override
	public void activate() {
		if (!isActive()) {
			super.activate();
			getModel().addListener(this);
		}
	}

	/**
	 * Upon deactivation, detach from the model element as a property change
	 * listener.
	 */
	@Override
	public void deactivate() {
		if (isActive()) {
			super.deactivate();
			getModel().removeListener(this);
		}
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		String prop = evt.getPropertyName();
		if (CHILDREN_PROP.equals(prop)) {
			refreshChildren();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public N getModel() {
		return (N) super.getModel();
	}

	@Override
	protected List<? extends Component> getModelChildren() {
		return getModel().getChildren();
	}

	/**
	 * Reset a child by cloning, removing and adding a new version of it. This
	 * method is useful when, for the same model class, the EditPart class
	 * differs.
	 *
	 * @param childEditPart The child EditPart to be reset.
	 */
	public void resetChildEditPart(EditPart childEditPart) {
		var index = getChildren().indexOf(childEditPart);
		var newNodeEditPart = createChild(childEditPart.getModel());
		removeChild(childEditPart);
		addChild(newNodeEditPart, index);
	}
}
