package org.openlca.app.editors.graphical.edit;

import static org.openlca.app.editors.graphical.model.commands.MinMaxCommand.*;
import static org.openlca.app.editors.graphical.requests.GraphRequests.*;

import java.util.Arrays;

import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.commands.CompoundCommand;
import org.openlca.app.M;
import org.openlca.app.components.graphics.model.Side;
import org.openlca.app.editors.graphical.model.MinMaxComponent;
import org.openlca.app.editors.graphical.model.Node;
import org.openlca.app.editors.graphical.model.commands.CollapseCommand;
import org.openlca.app.editors.graphical.model.commands.ExpandCommand;
import org.openlca.app.editors.graphical.model.commands.MinMaxCommand;

public class MinMaxEditPolicy extends GraphComponentEditPolicy {

	@Override
	public Command getCommand(Request request) {
		var node = (MinMaxComponent) getHost().getModel();
		if (REQ_OPEN.equals(request.getType())) {
			return getOpenCommand(node.isMinimized() ? MAXIMIZE : MINIMIZE);
		}
		if (REQ_MINIMIZE.equals(request.getType())) {
			if (!node.isMinimized())
				return getMinMaxCommand(MINIMIZE);
		}
		if (REQ_MAXIMIZE.equals(request.getType())) {
			if (node.isMinimized())
				return getMinMaxCommand(MAXIMIZE);
		}
		return super.getCommand(request);
	}

	private Command getMinMaxCommand(int type) {
		var childEditPart = getHost();
		var child = (MinMaxComponent) childEditPart.getModel();
		var command = new MinMaxCommand(type);
		command.setChild(child);
		return command;
	}

	private Command getOpenCommand(int type) {
		var childEditPart = getHost();
		var child = (MinMaxComponent) childEditPart.getModel();

		var cc = new CompoundCommand();
		cc.setLabel(M.Open);

		if (!(child instanceof Node node))
			return null;

		// True if the node is chained to the reference Node on one of its side.
		var chained = node.isReferenceProcess()
				|| node.isChainingReferenceNode(Side.INPUT)
				|| node.isChainingReferenceNode(Side.OUTPUT);
		for (var side : Arrays.asList(Side.INPUT, Side.OUTPUT)) {
			if (!node.isChainingReferenceNode(side)) {
				var com = type == MAXIMIZE && chained
						? new ExpandCommand(node, side, false)
						: type == MINIMIZE
						? new CollapseCommand(node, side) : null;
				if (com != null && com.canExecute())
					cc.add(com);
			}
		}

		cc.add(getMinMaxCommand(type));
		return cc.unwrap();
	}

}
