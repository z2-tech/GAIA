package org.openlca.app.editors.graphical.actions;

import static org.eclipse.gef.RequestConstants.*;

import java.util.Date;
import java.util.UUID;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.gef.ui.actions.WorkbenchPartAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.FormDialog;
import org.eclipse.ui.forms.IManagedForm;
import org.openlca.app.M;
import org.openlca.app.db.Database;
import org.openlca.app.editors.graphical.GraphActionIds;
import org.openlca.app.editors.graphical.GraphEditor;
import org.openlca.app.editors.graphical.model.Graph;
import org.openlca.app.editors.graphical.requests.GraphRequest;
import org.openlca.app.navigation.ModelTextFilter;
import org.openlca.app.navigation.NavigationTree;
import org.openlca.app.navigation.Navigator;
import org.openlca.app.navigation.elements.ModelElement;
import org.openlca.app.rcp.images.Icon;
import org.openlca.app.util.Labels;
import org.openlca.app.util.MsgBox;
import org.openlca.app.util.UI;
import org.openlca.app.viewers.Selections;
import org.openlca.app.viewers.Viewers;
import org.openlca.commons.Strings;
import org.openlca.core.model.ModelType;
import org.openlca.core.model.Process;
import org.openlca.core.model.ProcessType;
import org.openlca.core.model.descriptors.Descriptor;
import org.openlca.core.model.descriptors.RootDescriptor;

public class AddProcessAction extends WorkbenchPartAction {

	private Graph graph;
	private final GraphEditor editor;
	private org.eclipse.swt.graphics.Point cursorLocation;

	public AddProcessAction(GraphEditor part) {
		super(part);
		editor = part;
		setId(GraphActionIds.ADD_PROCESS);
		setText(M.AddProcess);
		setImageDescriptor(Icon.PROCESS_ADD.descriptor());
	}

	@Override
	public void run() {
		var d = new Dialog();
		d.open();
	}

	@Override
	protected boolean calculateEnabled() {
		cursorLocation = Display.getCurrent().getCursorLocation();
		if (editor != null) {
			graph = editor.getModel();
			return editor.getProductSystem() != null;
		}
		else return false;
	}

	private class Dialog extends FormDialog {

		final int _CREATE = 8;
		final int _SELECT = 16;
		final int _CANCEL = 32;

		TreeViewer tree;
		Text text;

		Dialog() {
			super(UI.shell());
			setBlockOnOpen(true);
		}

		@Override
		protected void createFormContent(IManagedForm mForm) {
			var tk = mForm.getToolkit();
			var body = UI.dialogBody(mForm.getForm(), tk);
			UI.gridLayout(body, 1);

			// create new text
			var nameLabel = UI.label(body, tk, M.CreateWithName);
			nameLabel.setFont(UI.boldFont());
			text = UI.text(body);
			text.addModifyListener(_ -> {
				var name = text.getText().trim();
				getButton(_CREATE).setEnabled(Strings.isNotBlank(name));
			});

			// tree
			var selectLabel = UI.label(body, tk, M.OrSelectExisting);
			selectLabel.setFont(UI.boldFont());
			tree = NavigationTree.forSingleSelection(body, ModelType.PROCESS);
			UI.gridData(tree.getControl(), true, true);
			tree.addFilter(new ModelTextFilter(text, tree));

			// enable/disable select button
			tree.addSelectionChangedListener(e -> {
				var d = unwrap(e.getSelection());
				getButton(_SELECT).setEnabled(d != null);
			});

			// add process on double click
			tree.addDoubleClickListener(e -> {
				var d = unwrap(e.getSelection());
				if (d != null) {
					addProcess(d);
				}
			});
		}

		private RootDescriptor unwrap(ISelection s) {
			var obj = Selections.firstOf(s);
			RootDescriptor d = null;
			if (obj instanceof RootDescriptor) {
				d = (RootDescriptor) obj;
			} else if (obj instanceof ModelElement) {
				d = ((ModelElement) obj).getContent();
			}
			if (d == null)
				return null;
			var matches = d.type == ModelType.PROCESS
				|| d.type == ModelType.PRODUCT_SYSTEM;
			return matches ? d : null;
		}

		@Override
		protected org.eclipse.swt.graphics.Point getInitialSize() {
			return UI.initialSizeOf(this, 600, 600);
		}

		@Override
		protected void createButtonsForButtonBar(Composite comp) {
			createButton(comp, _CREATE, M.CreateNew, false)
				.setEnabled(false);
			createButton(comp, _SELECT, M.SelectExisting, false)
				.setEnabled(false);
			createButton(comp, _CANCEL, M.Cancel, true);
		}

		@Override
		protected void buttonPressed(int button) {
			// cancel
			if (button == _CANCEL) {
				cancelPressed();
				return;
			}

			// select existing
			if (button == _SELECT) {
				var obj = Viewers.getFirstSelected(tree);
				if (!(obj instanceof ModelElement element)) {
					cancelPressed();
					return;
				}
				addProcess(element.getContent());
				return;
			}

			// create a new process
			if (button == _CREATE) {
				var name = text.getText().trim();
				if (Strings.isBlank(name)) {
					cancelPressed();
					return;
				}
				var process = new Process();
				process.name = name;
				process.refId = UUID.randomUUID().toString();
				process.processType = ProcessType.UNIT_PROCESS;
				process.lastChange = new Date().getTime();
				process = Database.get().insert(process);
				addProcess(Descriptor.of(process));
				Navigator.refresh();
			}
		}

		private void addProcess(RootDescriptor d) {
			var system = graph.getProductSystem();
			if (system.processes.contains(d.id)) {
				MsgBox.info(M.ProductSystemAlreadyContainsProcess
						+ " - " + Labels.name(d));
				cancelPressed();
				return;
			}

			var viewer = editor.getGraphicalViewer();
			var graphPart = editor.getEditPartOf(graph);
			if (graphPart == null)
				return;

			var loc = new Point(viewer.getControl().toControl(cursorLocation));
			var request = new GraphRequest(REQ_CREATE);
			request.setDescriptors(d);
			request.setLocation(loc);
			// Getting the command via GraphXYLayoutEditPolicy and executing it.
			var command = graphPart.getCommand(request);
			if (command.canExecute()) {
				execute(command);
			} else {
				MsgBox.info(M.ProcessCannotBeAddedToTheProductSystem
						+ " - " + Labels.name(d));
				cancelPressed();
			}

			super.okPressed();
		}

	}

}
